<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>HCR Rental Mobil</title>
        <link rel="shortcut icon" href="/logo-hcr.png">
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAdkwLsmw614EHlTLFKWZRRUVKRIPALKFc&libraries=places"></script>
        <?php echo app('Illuminate\Foundation\Vite')([
            'resources/css/app.css', 
            'resources/js/header.js', 
            'resources/js/slider.js',
            'resources/js/gmap.js'
        ]); ?>
    </head>
    <body>
        <a href="https://wa.me/6285368303446" class="z-1000">
            <div class="fixed flex right-3 bottom-2 w-40 h-14 bg-green-600 rounded-full overflow-hidden hover:w-44 z-1000">
                <img class="h-10 mt-2 ms-2" src="<?php echo e(asset('wa.png')); ?>"/>
                <h2 class="ms-2 mt-3.5 text-white font-semibold">Whatsapp</h2>
            </div>
        </a>
        <div id="main-header" class="fixed w-full sm:min-h-24 md:min-h-16 bg-slate-50 z-50 shadow-lg" dir="ltr">
            <div class="flex w-full">
                <div class="">
                    <img class="sm:max-h-24 md:max-h-16" src="<?php echo e(asset('logo-hcr.png')); ?>" alt="logo HCR Rental Mobil Lampung"/>
                </div>
                <div class="mx-3">
                    <h1 class="font-semibold text-left mt-2.5">HCR Rental Car</h1>
                    <p class="text-sm text-left text-red-hcr">Rental no.1 lampung</p>
                </div>
                <div class="sm:w-1/5 md:w-1/4 lg:w-1/3 xl:w-1/3"></div>
                <div class="relative flex gap-10 sm:mx-5 md:mx-16 xl:mx-36 sm:my-8 md:my-5 sm:hidden md:block xl:block">
                    <a class="text-2md font-semibold">Home</a>
                    <a class="text-2md font-semibold">Product</a>
                    <a class="text-2md font-semibold">About</a>
                </div>
            </div>
        </div>
        <div class="w-full sm:min-h-24 md:min-h-16"></div>
        <main class="min-h-screen w-full font-arial">
            <div class="slides w-full sm:max-h-84 lg:max-h-120 overflow-hidden fade">
                <img class="object-cover w-full sm:h-84 lg:h-120" src="<?php echo e(asset('banner-mobil.jpg')); ?>"/>
            </div>
            <div class="slides w-full sm:h-84 lg:h-120 overflow-hidden hidden fade">
                <img class="object-cover w-full sm:h-84 lg:h-120" src="<?php echo e(asset('banner2.jpg')); ?>"/>
            </div>
            <div class="slides w-full sm:h-84 lg:h-120 overflow-hidden hidden fade">
                <img class="object-cover w-full sm:h-84 lg:h-120" src="<?php echo e(asset('fortuner.jpg')); ?>"/>
            </div>
            <button type="button" id="next">next</button>
            <br/>
            <div class="relative sm:w-11/12 sm:left-10 lg:w-3/4 lg:left-1/8 xl:w-1/2 xl:left-1/4 mt-10">
                <h1 class="sm:text-3xl md:text-4xl lg:text-4xl xl:text-3xl mb-8 text-center text-blue-se">Penawaran Terbaik <span class="text-red-hcr">Saat ini</span></h1>
                <div class="grid sm:grid-cols-1 md:grid-cols-3 gap-5">
                    <div class="w-full aspect-square">
                        <div class="w-full h-3/5 mx-1 mt-1">
                            <img src="<?php echo e(asset('fortuner.jpg')); ?>"/>
                        </div>
                    </div>
                    <div class="w-full aspect-square">
                        <div class="w-full h-3/5 mx-1 mt-1">
                            <img src="<?php echo e(asset('hiace-commuter.jpg')); ?>"/>
                        </div>
                    </div>
                    <div class="w-full aspect-square">
                        <div class="w-full h-3/5 mx-1 mt-1">
                            <img src="<?php echo e(asset('hiace-premio.jpg')); ?>"/>
                        </div>
                    </div>
                    <div class="w-full aspect-square">
                        <div class="w-full h-3/5 mx-1 mt-1">
                            <img src="<?php echo e(asset('innova.jpg')); ?>"/>
                        </div>
                    </div>
                </div>
            </div>
            <br/>
            <div class="relative sm:w-11/12 lg:w-3/4 xl:w-1/2 sm:mx-auto mt-10">
                <h1 class="sm:text-3xl md:text-4xl lg:text-4xl xl:text-3xl mb-8 text-center text-blue-se">Mengapa Sewa Mobil <span class="text-red-hcr">Melalui HCR</span></h1>
                <div class="flex flex-wrap px-auto gap-5/100 gap-y-10">
                    <div class="sm:w-full md:w-3/10">
                        <img src="<?php echo e(asset('praktis.png')); ?>" class="sm:w-1/2 md:w-3/10 mx-auto"/>
                        <h2 class="sm:text-3xl md:text-xl text-center mt-5 mb-2 font-bold text-blue-se">Mudah & <span class="text-red-hcr">Fleksibel</span></h2>
                        <p class="sm:text-xl md:text-sm text-justify">Sistem reservasi kami yang user-friendly memungkinkan Anda untuk memesan kendaraan kapan saja dan di mana saja.</p>
                    </div>
                    <div class="sm:w-full md:w-3/10">
                        <img src="<?php echo e(asset('diskon.png')); ?>" class="sm:w-1/2 md:w-3/10 mx-auto"/>
                        <h2 class="sm:text-3xl md:text-xl text-center mt-5 mb-2 font-bold text-blue-se">Harga <span class="text-red-hcr">Kompetitif</span></h2>
                        <p class="sm:text-xl md:text-sm text-justify">Kami menawarkan harga yang bersaing dengan berbagai paket penyewaan harian, mingguan, maupun bulanan yang fleksibel.</p>
                    </div>
                    <div class="sm:w-full md:w-3/10">
                        <img src="<?php echo e(asset('cars.png')); ?>" class="sm:w-1/2 md:w-3/10 mx-auto"/>
                        <h2 class="sm:text-3xl md:text-xl text-center mt-5 mb-2 font-bold text-blue-se">Berkualitas</h2>
                        <p class="sm:text-xl md:text-sm text-justify">Armada kami terdiri dari kendaraan terbaru dengan kondisi yang terawat dan bersih.</p>
                    </div>
                    <div class="sm:w-full md:w-3/10">
                        <img src="<?php echo e(asset('sesuai.png')); ?>" class="sm:w-1/2 md:w-3/10 mx-auto"/>
                        <h2 class="sm:text-3xl md:text-xl text-center mt-5 mb-2 font-bold text-blue-se">Dukungan <span class="text-red-hcr">24/7</span></h2>
                        <p class="sm:text-xl md:text-sm text-justify">Layanan pelanggan kami selalu siap membantu Anda 24 jam sehari, 7 hari seminggu.</p>
                    </div>
                    <div class="sm:w-full md:w-3/10">
                        <img src="<?php echo e(asset('praktis.png')); ?>" class="sm:w-1/2 md:w-3/10 mx-auto"/>
                        <h2 class="sm:text-3xl md:text-xl text-center mt-5 mb-2 font-bold text-blue-se">Pelayanan <span class="text-red-hcr">Ramah</span></h2>
                        <p class="sm:text-xl md:text-sm text-justify">Staf kami siap melayani Anda dengan penuh keramahan dan profesionalisme untuk memastikan kepuasan Anda.</p>
                    </div>
                </div>
                <br/>
            </div>
            <br/>
            <div class="relative sm:w-11/12 sm:left-10 lg:w-3/4 lg:left-1/8 xl:w-1/2 xl:left-1/4 mt-10">
                <h1 class="sm:text-3xl md:text-4xl lg:text-4xl xl:text-3xl mb-8 text-center text-blue-se">Tentang <span class="text-red-hcr">HCR</span></h1>
                <p class="sm:text-xl md:text-sm text-justify">Di CV HELLEN CHRISA HCR, kami berdedikasi untuk menyediakan layanan rental mobil berkualitas tinggi dengan harga terjangkau untuk memenuhi berbagai kebutuhan transportasi Anda. Berdiri sejak 2007 dan setelah beberapa tahun akhirnya resmi menjadi perusahaan yang legal dengan nama CV HELLEN CHRISA HCR, kami terus berinovasi dan berkembang untuk memastikan setiap pelanggan mendapatkan pengalaman yang aman, nyaman, dan memuaskan.</p>
                <div class="flex flex-wrap gap-1/10">
                    <div class="sm:w-full md:w-4/11">
                        <br/>
                        <h2 class="sm:text-xl md:text-lg text-center text-blue-se">Visi</h2>
                        <p class="sm:text-xl md:text-sm text-justify">Visi kami adalah menjadi perusahaan rental mobil terdepan yang dikenal luas atas kualitas layanan prima, kendaraan berkualitas, serta komitmen terhadap kepuasan pelanggan.</p>
                    </div>
                    <div class="sm:w-full md:w-4/11">
                        <br/>
                        <h2 class="sm:text-xl md:text-lg text-center text-red-hcr">Misi</h2>
                        <p class="sm:text-xl md:text-sm text-justify">Misi kami adalah menawarkan solusi transportasi yang handal, fleksibel, dan efisien dengan beragam pilihan kendaraan yang dapat disesuaikan dengan kebutuhan Anda, baik untuk tujuan pribadi, bisnis, maupun wisata.</p>
                    </div>
                </div>
                <br/>
                <p class="sm:text-xl md:text-sm">Di CV HELLEN CHRISA HCR, kami menawarkan berbagai jenis kendaraan yang dapat Anda pilih sesuai kebutuhan, termasuk:</p>
                <ul class="list-inside list-disc mt-2">
                    <li>Mobil Sedan</li>
                    <li>Mobil SUV</li>
                    <li>Mobil MPV</li>
                    <li>Mobil Mewah</li>
                    <li>Minibus</li>
                </ul>
                <p class="sm:text-xl md:text-sm mt-2 text-justify">Kami berkomitmen untuk selalu menyediakan layanan terbaik dan menjaga kepercayaan yang telah diberikan oleh pelanggan. Kepuasan Anda adalah prioritas utama kami, karena itulah kami selalu berupaya memberikan nilai lebih dalam setiap layanan yang kami tawarkan.</p>
            </div>
            <div>
                <
            </div>
        </main>
        <div class="w-full sm:h-200 md:h-100 bg-red-hcr mt-20">
            <div class="relative sm:w-11/12 lg:w-7/8 xl:w-3/4 mx-auto mt-10">
                <div class="relative flex sm:gap-x-0 md:gap-x-32 gap-y-10 sm:flex-wrap md:flex-nowrap top-10">
                    <div class="sm:w-full md:w-auto">
                        <h2 class="text-lg text-white mb-3">Layanan Pelanggan</h2>
                        <div class="flex gap-5">
                            <img src="<?php echo e(asset('telp.png')); ?>" class="h-10 my-2"/>
                            <div>
                                <h2 class="text-lg font-semibold text-white">085368303446 (Tomi)</h2>
                                <h2 class="text-lg font-semibold text-white">082280008848 (Mikel)</h2>
                            </div>
                        </div>
                    </div>
                    <div class="sm:w-full md:w-auto">
                        <h2 class="text-lg text-white mb-3">Temukan Kami</h2>
                    </div>
                    <div class="sm:w-full md:w-auto">
                        <h2 class="text-lg text-white mb-3">Lokasi</h2>
                        <p class="max-w-80 text-white text-sm mb-2">Jl Cipto Mangunkusumo Gg Punggut O, Sumur Batu, Teluk Betung utara, Bandar Lampung, Lampung, 35214</p>
                        <div id="map" class="sm:w-full md:w-80 sm:h-80 md:h-44 z-50"></div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html><?php /**PATH C:\cesar\webApp\hrcrentalcar\resources\views\home.blade.php ENDPATH**/ ?>