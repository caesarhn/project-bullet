
const slides = document.getElementsByClassName('slides')
const next = document.getElementById('next')
let i = 0

function moveSlide(){
    if(i < 2){
        i++
    }else{
        i = 0
    }

    for(let x=0; x < slides.length; x++){
        slides[x].classList.add('hidden')
    }
    slides[i].classList.remove('hidden')
}

next.addEventListener('click', () => {
    moveSlide()
})

let slideInterval = setInterval(function() {
    moveSlide()
  }, 4000);