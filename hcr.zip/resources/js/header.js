let lastScroll = 0

const header = document.getElementById('main-header')

window.addEventListener('scroll', () => {
    let scroll = document.documentElement.scrollTop
    //console.log(scroll)
    if(scroll > 100){
        if(scroll > lastScroll){
            header.classList.add('hide')
        }else{
            header.classList.remove('hide')
        }
    }
    lastScroll = scroll
})